import { createFileRoute } from "@tanstack/react-router";
import { CrookApp } from "@/components/crook/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <CrookApp />;
}
