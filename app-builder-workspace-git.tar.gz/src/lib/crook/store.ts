import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CopyKey } from "@/lib/crook/i18n";
import type { Incident, LogItem, LogTone, Settings } from "@/lib/crook/types";
import { T1, T2, T3 } from "@/lib/crook/types";

const samples: Incident[] = [
  {
    id: "sample-1",
    at: T1,
    attempts: 3,
    method: "pin",
    photo: null,
    photoMode: "sample",
    lat: 24.71355,
    lng: 46.6753,
    accuracy: 18,
    email: "owner@mailbox.com",
    deviceName: "Android · الجهاز الأساسي",
    ownerName: "المالك",
    driveCopy: true,
    sample: true,
    seed: 0,
  },
  {
    id: "sample-2",
    at: T2,
    attempts: 2,
    method: "pattern",
    photo: null,
    photoMode: "sample",
    lat: 21.48581,
    lng: 39.1925,
    accuracy: 42,
    email: "owner@mailbox.com",
    deviceName: "Android · الجهاز الأساسي",
    ownerName: "المالك",
    driveCopy: false,
    sample: true,
    seed: 1,
  },
  {
    id: "sample-3",
    at: T3,
    attempts: 4,
    method: "pin",
    photo: null,
    photoMode: "sample",
    lat: 25.20485,
    lng: 55.27078,
    accuracy: 27,
    email: "owner@mailbox.com",
    deviceName: "Android · الجهاز الأساسي",
    ownerName: "المالك",
    driveCopy: true,
    sample: true,
    seed: 2,
  },
];

const seedEvents: LogItem[] = [
  { id: "e1", at: T1, tone: "hot", k: "mailEvent" },
  { id: "e2", at: T1 - 20_000, tone: "warn", k: "gpsEvent" },
  { id: "e3", at: T1 - 40_000, tone: "hot", k: "thresholdEvent" },
  { id: "e4", at: T1 - 80_000, tone: "warn", k: "failEvent", n: 3 },
  { id: "e5", at: T2, tone: "hot", k: "mailEvent" },
  { id: "e6", at: T3, tone: "idle", k: "listenEvent" },
];

export const defaultSettings: Settings = {
  armed: true,
  threshold: 2,
  pin: "2580",
  pattern: [0, 1, 2, 5, 8],
  email: "owner@mailbox.com",
  deviceName: "Android · الجهاز الأساسي",
  ownerName: "المالك",
  flash: false,
  locale: "ar",
  driveCopy: true,
  method: "pin",
};

type CrookState = {
  settings: Settings;
  incidents: Incident[];
  events: LogItem[];
  fails: number;
  focusId: string | null;
  notice: CopyKey | null;
  patchSettings: (partial: Partial<Settings>) => void;
  pushEvent: (item: { tone: LogTone; k: CopyKey; n?: number }) => void;
  addIncident: (incident: Incident) => void;
  removeIncident: (id: string) => void;
  clearIncidents: () => void;
  noteFail: () => void;
  setFocus: (id: string | null) => void;
  notify: (key: CopyKey) => void;
  dismiss: () => void;
};

export const useCrook = create<CrookState>()(
  persist(
    (set) => ({
      settings: defaultSettings,
      incidents: samples,
      events: seedEvents,
      fails: 9,
      focusId: null,
      notice: null,
      patchSettings: (partial) =>
        set((state) => ({ settings: { ...state.settings, ...partial } })),
      pushEvent: (item) =>
        set((state) => ({
          events: [
            {
              id: `e-${Date.now()}-${state.events.length}`,
              at: Date.now(),
              tone: item.tone,
              k: item.k,
              n: item.n,
            },
            ...state.events,
          ].slice(0, 40),
        })),
      addIncident: (incident) =>
        set((state) => ({
          incidents: [incident, ...state.incidents].slice(0, 16),
          focusId: incident.id,
        })),
      removeIncident: (id) =>
        set((state) => ({
          incidents: state.incidents.filter((item) => item.id !== id),
          focusId: state.focusId === id ? null : state.focusId,
        })),
      clearIncidents: () =>
        set({
          incidents: [],
          fails: 0,
          focusId: null,
          events: [{ id: `boot-${Date.now()}`, at: Date.now(), tone: "idle", k: "bootEvent" }],
        }),
      noteFail: () => set((state) => ({ fails: state.fails + 1 })),
      setFocus: (id) => set({ focusId: id }),
      notify: (key) => set({ notice: key }),
      dismiss: () => set({ notice: null }),
    }),
    {
      name: "crookcatcher-v1",
      skipHydration: true,
      partialize: (state) => ({
        settings: state.settings,
        incidents: state.incidents,
        events: state.events,
        fails: state.fails,
      }),
    },
  ),
);
