import type { Locale } from "@/lib/crook/i18n";
import { t } from "@/lib/crook/i18n";
import type { Incident } from "@/lib/crook/types";

export function formatWhen(ts: number, locale: Locale) {
  return new Intl.DateTimeFormat(locale === "ar" ? "ar" : "en-GB", {
    numberingSystem: "latn",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(ts);
}

export function mapsUrl(lat: number, lng: number) {
  return `https://maps.google.com/?q=${lat.toFixed(5)},${lng.toFixed(5)}`;
}

export function samePattern(a: number[], b: number[]) {
  return a.length === b.length && a.every((n, i) => n === b[i]);
}

export function buildPacket(incident: Incident, locale: Locale) {
  const where =
    incident.lat != null && incident.lng != null
      ? `${incident.lat.toFixed(5)}, ${incident.lng.toFixed(5)}\n${mapsUrl(incident.lat, incident.lng)}`
      : t(locale, "noLocation");
  const method = incident.method === "pin" ? t(locale, "methodPin") : t(locale, "methodPattern");
  return [
    t(locale, "packetSubject"),
    `${t(locale, "toEmail")}: ${incident.email}`,
    `${t(locale, "device")}: ${incident.deviceName}`,
    `${t(locale, "methodLabel")}: ${method}`,
    `${t(locale, "attemptsShort")}: ${incident.attempts}`,
    `${t(locale, "when")}: ${formatWhen(incident.at, locale)}`,
    `${t(locale, "location")}: ${where}`,
    `${t(locale, "packetPhoto")}: ${incident.photoMode}`,
    incident.driveCopy ? t(locale, "driveOn") : t(locale, "driveOff"),
    t(locale, "statusReady"),
  ].join("\n");
}
