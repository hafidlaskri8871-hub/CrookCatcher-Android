export type Fix = { lat: number; lng: number; accuracy: number };

export function openCamera(): Promise<MediaStream | null> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      settled = true;
      resolve(null);
    }, 3500);
    navigator.mediaDevices
      .getUserMedia({
        audio: false,
        video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 960 } },
      })
      .then((stream) => {
        if (settled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }
        clearTimeout(timer);
        resolve(stream);
      })
      .catch(() => {
        if (settled) return;
        clearTimeout(timer);
        resolve(null);
      });
  });
}

export function locate(): Promise<Fix | null> {
  if (typeof navigator === "undefined" || !navigator.geolocation) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: Math.round(pos.coords.accuracy),
        }),
      () => resolve(null),
      { enableHighAccuracy: true, timeout: 4000, maximumAge: 60_000 },
    );
  });
}

export async function captureFrame(stream: MediaStream, stamp: string): Promise<string> {
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.srcObject = stream;
  try {
    await video.play();
    if (!video.videoWidth) {
      await wait(280);
    }
    await wait(180);
    const w = 480;
    const ratio = video.videoWidth ? video.videoHeight / video.videoWidth : 1.2;
    const h = Math.max(320, Math.round(w * ratio));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx || !video.videoWidth) throw new Error("frame");
    ctx.drawImage(video, 0, 0, w, h);
    paintHud(ctx, w, h, stamp);
    return canvas.toDataURL("image/jpeg", 0.72);
  } finally {
    stream.getTracks().forEach((track) => track.stop());
    video.srcObject = null;
  }
}

export function syntheticStill(stamp: string): string {
  const w = 480;
  const h = 560;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.fillStyle = "#101318";
  ctx.fillRect(0, 0, w, h);
  const image = ctx.getImageData(0, 0, w, h);
  for (let i = 0; i < image.data.length; i += 16) {
    const n = 16 + Math.random() * 22;
    image.data[i] = n + 8;
    image.data[i + 1] = n + 6;
    image.data[i + 2] = n;
    image.data[i + 3] = 255;
  }
  ctx.putImageData(image, 0, 0);
  const glow = ctx.createRadialGradient(w / 2, h * 0.42, 20, w / 2, h * 0.45, 260);
  glow.addColorStop(0, "rgba(224,161,90,0.16)");
  glow.addColorStop(1, "rgba(16,19,24,0.2)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(244,239,230,0.16)";
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.62, 78, 46, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.4, 34, 42, 0, 0, Math.PI * 2);
  ctx.fill();
  paintHud(ctx, w, h, stamp);
  return canvas.toDataURL("image/jpeg", 0.72);
}

function paintHud(ctx: CanvasRenderingContext2D, w: number, h: number, stamp: string) {
  ctx.fillStyle = "rgba(16,19,24,0.66)";
  ctx.fillRect(0, h - 44, w, 44);
  ctx.fillStyle = "#f4efe6";
  ctx.font = "14px monospace";
  ctx.fillText(`CAM-F   ${stamp}`, 16, h - 16);
}

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
