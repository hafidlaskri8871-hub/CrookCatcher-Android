import type { CopyKey, Locale } from "@/lib/crook/i18n";

export type UnlockMethod = "pin" | "pattern";
export type PhotoMode = "camera" | "synthetic" | "sample";

export type Settings = {
  armed: boolean;
  threshold: number;
  pin: string;
  pattern: number[];
  email: string;
  deviceName: string;
  ownerName: string;
  flash: boolean;
  locale: Locale;
  driveCopy: boolean;
  method: UnlockMethod;
};

export type Incident = {
  id: string;
  at: number;
  attempts: number;
  method: UnlockMethod;
  photo: string | null;
  photoMode: PhotoMode;
  lat: number | null;
  lng: number | null;
  accuracy: number | null;
  email: string;
  deviceName: string;
  ownerName: string;
  driveCopy: boolean;
  sample: boolean;
  seed: number;
};

export type LogTone = "idle" | "warn" | "good" | "hot";

export type LogItem = {
  id: string;
  at: number;
  tone: LogTone;
  k: CopyKey;
  n?: number;
};

export type Phase = 0 | 1 | 2 | 3 | 4 | 5;

export const T1 = Date.UTC(2026, 9, 30, 18, 14);
export const T2 = Date.UTC(2026, 9, 29, 23, 41);
export const T3 = Date.UTC(2026, 9, 27, 15, 6);
