import type { CopyKey } from "@/lib/crook/i18n";
import { t } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";
import { PageTitle, Panel } from "@/components/crook/ui";

const steps: CopyKey[] = ["how1", "how2", "how3", "how4", "how5"];
const stepTitles: CopyKey[] = ["stepListen", "stepThreshold", "stepCamera", "stepGps", "stepDispatch"];

const components: { title: CopyKey; body: CopyKey; tech: CopyKey }[] = [
  { title: "c1", body: "c1body", tech: "stepListenTech" },
  { title: "c2", body: "c2body", tech: "stepCameraTech" },
  { title: "c3", body: "c3body", tech: "stepGpsTech" },
  { title: "c4", body: "c4body", tech: "stepDispatchTech" },
];

const stack: { layer: CopyKey; tech: CopyKey; body: CopyKey }[] = [
  { layer: "s1layer", tech: "s1tech", body: "s1body" },
  { layer: "s2layer", tech: "s2tech", body: "s2body" },
  { layer: "s3layer", tech: "s3tech", body: "s3body" },
  { layer: "s4layer", tech: "s4tech", body: "s4body" },
  { layer: "s5layer", tech: "s5tech", body: "s5body" },
];

const perms: { title: CopyKey; body: CopyKey }[] = [
  { title: "p1", body: "p1body" },
  { title: "p2", body: "p2body" },
  { title: "p3", body: "p3body" },
];

export function Architecture() {
  const locale = useCrook((s) => s.settings.locale);

  return (
    <div className="flex flex-col gap-6">
      <PageTitle kicker={t(locale, "archKicker")} title={t(locale, "archTitle")} lede={t(locale, "archLede")} />
      <blockquote className="border-s-2 border-signal ps-4 text-lg text-fg">{t(locale, "quote")}</blockquote>

      <section>
        <h2 className="text-xl font-semibold text-fg">{t(locale, "howTitle")}</h2>
        <ol className="mt-3 flex flex-col gap-3">
          {steps.map((key, index) => (
            <li key={key} className="grid grid-cols-[2.5rem_minmax(0,1fr)] gap-3 rounded-2xl border border-line bg-surface p-4">
              <span className="font-mono text-lg text-signal">{index + 1}</span>
              <div>
                <p className="font-medium text-fg">{t(locale, stepTitles[index] ?? "stepListen")}</p>
                <p className="mt-1 text-sm text-muted">{t(locale, key)}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-fg">{t(locale, "compTitle")}</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {components.map((item) => (
            <Panel key={item.title}>
              <p className="font-mono text-xs text-signal">{t(locale, item.tech)}</p>
              <h3 className="mt-2 font-medium text-fg">{t(locale, item.title)}</h3>
              <p className="mt-2 text-sm text-muted">{t(locale, item.body)}</p>
            </Panel>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-fg">{t(locale, "stackTitle")}</h2>
        <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line">
          {stack.map((row) => (
            <li key={row.tech} className="grid gap-1 bg-surface p-4 md:grid-cols-[11rem_minmax(0,1fr)] md:gap-4">
              <p className="font-mono text-sm text-signal">{t(locale, row.tech)}</p>
              <div>
                <p className="font-medium text-fg">{t(locale, row.layer)}</p>
                <p className="mt-1 text-sm text-muted">{t(locale, row.body)}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-fg">{t(locale, "permTitle")}</h2>
        <ul className="mt-3 flex flex-col gap-3">
          {perms.map((perm) => (
            <li key={perm.title} className="rounded-2xl border border-line bg-surface p-4">
              <p className="font-medium text-fg">{t(locale, perm.title)}</p>
              <p className="mt-1 text-sm text-muted">{t(locale, perm.body)}</p>
            </li>
          ))}
        </ul>
      </section>

      <Panel className="border-s-2 border-s-signal">
        <h2 className="font-medium text-fg">{t(locale, "noteTitle")}</h2>
        <p className="mt-2 text-sm text-muted">{t(locale, "noteBody")}</p>
      </Panel>
    </div>
  );
}
