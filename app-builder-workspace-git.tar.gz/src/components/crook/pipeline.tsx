import { cn } from "@/lib/cn";
import type { CopyKey, Locale } from "@/lib/crook/i18n";
import { t } from "@/lib/crook/i18n";
import type { Phase } from "@/lib/crook/types";

const steps: { title: CopyKey; tech: CopyKey; at: Phase }[] = [
  { title: "stepListen", tech: "stepListenTech", at: 0 },
  { title: "stepThreshold", tech: "stepThresholdTech", at: 1 },
  { title: "stepCamera", tech: "stepCameraTech", at: 2 },
  { title: "stepGps", tech: "stepGpsTech", at: 3 },
  { title: "stepDispatch", tech: "stepDispatchTech", at: 4 },
];

export function Pipeline({ phase, armed, locale }: { phase: Phase; armed: boolean; locale: Locale }) {
  return (
    <ol className="flex flex-col">
      {steps.map((step, index) => {
        const listening = phase === 0 && index === 0 && armed;
        const current = phase > 0 && phase < 5 && phase === step.at;
        const done = phase > step.at;
        const lit = done || current || listening;
        return (
          <li
            key={step.title}
            className={cn(
              "border-s-2 py-3 ps-4",
              lit ? "border-signal" : "border-line",
              current && "bg-raised",
            )}
          >
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "size-1.5 rounded-full",
                  lit ? "bg-signal" : "bg-faint",
                  (current || listening) && "live-dot",
                )}
              />
              <p className={cn("font-medium", lit ? "text-fg" : "text-muted")}>{t(locale, step.title)}</p>
            </div>
            <p className="mt-1 font-mono text-xs text-faint">{t(locale, step.tech)}</p>
          </li>
        );
      })}
    </ol>
  );
}
