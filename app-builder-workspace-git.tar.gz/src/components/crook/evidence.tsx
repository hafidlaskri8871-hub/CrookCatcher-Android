import { cn } from "@/lib/cn";
import type { Locale } from "@/lib/crook/i18n";
import { t } from "@/lib/crook/i18n";
import type { PhotoMode } from "@/lib/crook/types";

const spots = ["left-6 top-8", "right-6 top-10", "left-8 bottom-8"];

export function EvidenceFrame({
  photo,
  mode,
  stamp,
  seed = 0,
  locale,
  compact = false,
}: {
  photo: string | null;
  mode: PhotoMode;
  stamp: string;
  seed?: number;
  locale: Locale;
  compact?: boolean;
}) {
  return (
    <figure className="relative overflow-hidden rounded-xl border border-line bg-raised">
      {photo ? (
        <img
          src={photo}
          alt={mode === "camera" ? t(locale, "cameraShot") : t(locale, "syntheticShot")}
          className={cn("w-full object-cover", compact ? "h-24" : "h-52 md:h-64")}
        />
      ) : (
        <div className={cn("relative w-full", compact ? "h-24" : "h-52 md:h-64")}>
          <div className={cn("absolute size-24 rounded-full bg-fg/10 blur-2xl", spots[seed % spots.length])} />
          <div className="absolute top-1/2 left-1/2 size-12 -translate-x-1/2 -translate-y-6 rounded-full bg-fg/15" />
          <div className="absolute top-2/3 left-1/2 h-10 w-20 -translate-x-1/2 rounded-full bg-fg/10" />
          <div className="scanlines absolute inset-0 opacity-70" />
        </div>
      )}
      <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-between bg-bg/80 px-2 py-1 font-mono text-xs text-fg">
        <span>{mode === "sample" ? t(locale, "demoStill") : t(locale, "camLabel")}</span>
        {stamp && !compact ? <span>{stamp}</span> : null}
      </figcaption>
    </figure>
  );
}
