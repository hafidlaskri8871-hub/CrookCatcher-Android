import { useEffect, useState } from "react";
import { PatternGlyph, PatternPad } from "@/components/crook/pattern";
import { Field, PageTitle, Panel, SolidButton, ToggleRow, fieldClass } from "@/components/crook/ui";
import { t } from "@/lib/crook/i18n";
import type { Locale } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";
import { cn } from "@/lib/cn";

export function Settings() {
  const settings = useCrook((s) => s.settings);
  const patchSettings = useCrook((s) => s.patchSettings);
  const pushEvent = useCrook((s) => s.pushEvent);
  const clearIncidents = useCrook((s) => s.clearIncidents);
  const notify = useCrook((s) => s.notify);
  const locale = settings.locale;
  const [pinDraft, setPinDraft] = useState(settings.pin);
  const [path, setPath] = useState<number[]>([]);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    setPinDraft(settings.pin);
  }, [settings.pin]);

  function setLocale(next: Locale) {
    patchSettings({ locale: next });
    document.documentElement.lang = next === "ar" ? "ar" : "en";
    document.documentElement.dir = next === "ar" ? "rtl" : "ltr";
  }

  function toggleArmed() {
    const armed = !settings.armed;
    patchSettings({ armed });
    pushEvent({ tone: armed ? "good" : "idle", k: armed ? "armEvent" : "disarmEvent" });
    notify(armed ? "notifyArmed" : "notifyDisarmed");
  }

  return (
    <div className="flex max-w-2xl flex-col gap-6">
      <PageTitle kicker={t(locale, "prefsKicker")} title={t(locale, "prefsTitle")} lede={t(locale, "permAsk")} />

      <Panel>
        <h2 className="font-medium text-fg">{t(locale, "sectionGuard")}</h2>
        <div className="mt-2 divide-y divide-line">
          <ToggleRow on={settings.armed} label={t(locale, "labelArmed")} body={t(locale, "armedBody")} onClick={toggleArmed} />
          <ToggleRow
            on={settings.flash}
            label={t(locale, "labelFlash")}
            body={t(locale, "flashBody")}
            onClick={() => patchSettings({ flash: !settings.flash })}
          />
          <ToggleRow
            on={settings.driveCopy}
            label={t(locale, "labelDrive")}
            body={t(locale, "driveBody")}
            onClick={() => patchSettings({ driveCopy: !settings.driveCopy })}
          />
        </div>
        <p className="mt-4 text-sm font-medium text-fg">{t(locale, "labelThreshold")}</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {[1, 2, 3, 4, 5].map((count) => (
            <button
              key={count}
              type="button"
              onClick={() => patchSettings({ threshold: count })}
              className={cn(
                "grid size-11 place-items-center rounded-xl font-mono",
                settings.threshold === count ? "bg-signal text-on-signal" : "border border-line text-fg",
              )}
            >
              {count}
            </button>
          ))}
        </div>
      </Panel>

      <Panel className="flex flex-col gap-4">
        <h2 className="font-medium text-fg">{t(locale, "sectionId")}</h2>
        <Field label={t(locale, "labelOwner")}>
          <input
            className={fieldClass}
            value={settings.ownerName}
            onChange={(event) => patchSettings({ ownerName: event.target.value })}
          />
        </Field>
        <Field label={t(locale, "labelDevice")}>
          <input
            className={fieldClass}
            value={settings.deviceName}
            onChange={(event) => patchSettings({ deviceName: event.target.value })}
          />
        </Field>
        <Field label={t(locale, "labelEmail")}>
          <input
            className={fieldClass}
            inputMode="email"
            autoComplete="email"
            value={settings.email}
            onChange={(event) => patchSettings({ email: event.target.value })}
          />
        </Field>
      </Panel>

      <Panel className="flex flex-col gap-4">
        <h2 className="font-medium text-fg">{t(locale, "sectionSecret")}</h2>
        <Field label={t(locale, "labelPin")} hint={t(locale, "pinHint")}>
          <input
            className={fieldClass}
            inputMode="numeric"
            autoComplete="off"
            maxLength={4}
            value={pinDraft}
            onChange={(event) => {
              const next = event.target.value.replace(/\D/g, "").slice(0, 4);
              setPinDraft(next);
              if (next.length === 4) patchSettings({ pin: next });
            }}
          />
        </Field>
        <div>
          <p className="text-sm font-medium text-fg">{t(locale, "labelPattern")}</p>
          <p className="mt-1 text-sm text-muted">{t(locale, "patternHint")}</p>
          <div className="mt-3 flex items-center gap-4">
            <PatternGlyph path={settings.pattern} />
            <span className="font-mono text-xs text-faint">{settings.pattern.map((n) => n + 1).join(" → ")}</span>
          </div>
          <div className="mt-4">
            <PatternPad path={path} onPath={setPath} />
          </div>
          <div className="mt-3">
            <SolidButton
              disabled={path.length < 4}
              onClick={() => {
                patchSettings({ pattern: path });
                setPath([]);
                notify("patternSaved");
              }}
            >
              {t(locale, "confirm")}
            </SolidButton>
          </div>
        </div>
      </Panel>

      <Panel>
        <h2 className="font-medium text-fg">{t(locale, "sectionLang")}</h2>
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => setLocale("ar")}
            className={cn(
              "min-h-11 rounded-xl px-4 text-sm",
              locale === "ar" ? "bg-signal text-on-signal" : "border border-line text-fg",
            )}
          >
            {t(locale, "langAr")}
          </button>
          <button
            type="button"
            onClick={() => setLocale("en")}
            className={cn(
              "min-h-11 rounded-xl px-4 text-sm",
              locale === "en" ? "bg-signal text-on-signal" : "border border-line text-fg",
            )}
          >
            {t(locale, "langEn")}
          </button>
        </div>
      </Panel>

      <Panel>
        <h2 className="font-medium text-fg">{t(locale, "sectionData")}</h2>
        <div className="mt-3">
          <button
            type="button"
            onClick={() => {
              if (!confirmClear) {
                setConfirmClear(true);
                return;
              }
              clearIncidents();
              notify("cleared");
              setConfirmClear(false);
            }}
            className="min-h-11 rounded-xl border border-line px-4 text-sm text-fg"
          >
            {confirmClear ? t(locale, "clearConfirm") : t(locale, "clearCases")}
          </button>
        </div>
      </Panel>
    </div>
  );
}
