export type View = "ops" | "lock" | "cases" | "arch" | "prefs";
