import { cn } from "@/lib/cn";

const DOTS = [0, 1, 2, 3, 4, 5, 6, 7, 8];

function pos(index: number) {
  const col = index % 3;
  const row = Math.floor(index / 3);
  return { x: (col + 0.5) * (100 / 3), y: (row + 0.5) * (100 / 3) };
}

export function PatternPad({
  path,
  onPath,
  shake,
}: {
  path: number[];
  onPath: (next: number[]) => void;
  shake?: boolean;
}) {
  function hit(index: number) {
    if (path.includes(index)) return;
    onPath([...path, index]);
  }

  return (
    <div className={cn("relative mx-auto aspect-square w-full max-w-64 touch-none", shake && "shake")}>
      <svg className="absolute inset-0 size-full" viewBox="0 0 100 100" aria-hidden="true">
        {path.slice(1).map((id, index) => {
          const from = pos(path[index] ?? 0);
          const to = pos(id);
          return (
            <line
              key={`${path[index]}-${id}`}
              x1={from.x}
              y1={from.y}
              x2={to.x}
              y2={to.y}
              stroke="var(--color-signal)"
              strokeWidth="1.6"
              strokeLinecap="round"
            />
          );
        })}
      </svg>
      <div className="relative grid h-full grid-cols-3">
        {DOTS.map((index) => {
          const on = path.includes(index);
          const order = path.indexOf(index);
          return (
            <div key={index} className="grid place-items-center">
              <button
                type="button"
                data-dot={index}
                aria-pressed={on}
                onPointerDown={() => hit(index)}
                className="grid size-14 place-items-center"
              >
                <span
                  className={cn(
                    "grid size-5 place-items-center rounded-full border-2",
                    on ? "border-signal bg-signal text-on-signal" : "border-muted bg-transparent",
                  )}
                >
                  {on ? <span className="font-mono text-xs">{order + 1}</span> : null}
                </span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function PatternGlyph({ path }: { path: number[] }) {
  return (
    <div className="grid size-16 grid-cols-3 gap-1">
      {DOTS.map((index) => {
        const order = path.indexOf(index);
        const on = order >= 0;
        return (
          <span
            key={index}
            className={cn(
              "grid place-items-center rounded-full border text-xs font-mono",
              on ? "border-signal bg-signal text-on-signal" : "border-line text-transparent",
            )}
          >
            {on ? order + 1 : "·"}
          </span>
        );
      })}
    </div>
  );
}
