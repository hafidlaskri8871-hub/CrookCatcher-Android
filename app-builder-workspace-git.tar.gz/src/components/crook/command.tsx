import { EvidenceFrame } from "@/components/crook/evidence";
import { Pipeline } from "@/components/crook/pipeline";
import { PageTitle, Panel } from "@/components/crook/ui";
import { formatWhen } from "@/lib/crook/format";
import { t } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";
import type { View } from "@/components/crook/shell-types";

export function Command({ go }: { go: (view: View) => void }) {
  const settings = useCrook((s) => s.settings);
  const incidents = useCrook((s) => s.incidents);
  const events = useCrook((s) => s.events);
  const fails = useCrook((s) => s.fails);
  const setFocus = useCrook((s) => s.setFocus);
  const locale = settings.locale;
  const latest = incidents[0];

  const stats = [
    { label: t(locale, "statFails"), value: String(fails) },
    { label: t(locale, "statCases"), value: String(incidents.length) },
    { label: t(locale, "statThreshold"), value: String(settings.threshold) },
    { label: t(locale, "statLast"), value: latest ? formatWhen(latest.at, locale) : t(locale, "none") },
  ];

  return (
    <div className="flex flex-col gap-6">
      <PageTitle kicker={t(locale, "opsKicker")} title={t(locale, "opsTitle")} lede={t(locale, "opsLede")} />
      <p className="font-mono text-xs text-muted">
        {settings.armed ? t(locale, "listening") : t(locale, "paused")}
      </p>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((stat) => (
          <Panel key={stat.label} className="p-4">
            <p className="text-sm text-muted">{stat.label}</p>
            <p className="mt-2 font-mono text-xl leading-tight text-fg">{stat.value}</p>
          </Panel>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <Panel>
          <h2 className="font-medium text-fg">{t(locale, "pipelineTitle")}</h2>
          <div className="mt-3">
            <Pipeline phase={0} armed={settings.armed} locale={locale} />
          </div>
        </Panel>
        <Panel>
          <h2 className="font-medium text-fg">{t(locale, "logTitle")}</h2>
          <ul className="mt-3 flex max-h-80 flex-col gap-3 overflow-auto">
            {events.slice(0, 8).map((event) => (
              <li key={event.id} className="flex gap-3">
                <span
                  className={
                    event.tone === "idle"
                      ? "mt-2 size-1.5 shrink-0 rounded-full bg-faint"
                      : event.tone === "good"
                        ? "mt-2 size-1.5 shrink-0 rounded-full bg-fg"
                        : "mt-2 size-1.5 shrink-0 rounded-full bg-signal"
                  }
                />
                <div className="min-w-0">
                  <p className="text-sm text-fg">{t(locale, event.k, event.n != null ? { n: event.n } : undefined)}</p>
                  <p className="font-mono text-xs text-faint">{formatWhen(event.at, locale)}</p>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
      <section>
        <div className="mb-3 flex items-end justify-between gap-3">
          <h2 className="font-medium text-fg">{t(locale, "recentTitle")}</h2>
          <button type="button" onClick={() => go("cases")} className="min-h-11 text-sm text-signal">
            {t(locale, "viewAll")}
          </button>
        </div>
        {incidents.length === 0 ? (
          <Panel>
            <p className="text-muted">{t(locale, "emptyCases")}</p>
          </Panel>
        ) : (
          <div className="grid gap-3 md:grid-cols-3">
            {incidents.slice(0, 3).map((incident) => (
              <button
                key={incident.id}
                type="button"
                onClick={() => {
                  setFocus(incident.id);
                  go("cases");
                }}
                className="rounded-2xl border border-line bg-surface p-3 text-start"
              >
                <EvidenceFrame
                  photo={incident.photo}
                  mode={incident.photoMode}
                  stamp={formatWhen(incident.at, locale)}
                  seed={incident.seed}
                  locale={locale}
                />
                <p className="mt-3 text-sm font-medium text-fg">{t(locale, "attempts", { n: incident.attempts })}</p>
                <p className="mt-1 font-mono text-xs text-muted">
                  {incident.lat != null && incident.lng != null
                    ? `${incident.lat.toFixed(4)}, ${incident.lng.toFixed(4)}`
                    : t(locale, "noLocation")}
                </p>
                {incident.sample ? <p className="mt-2 text-xs text-signal">{t(locale, "sample")}</p> : null}
              </button>
            ))}
          </div>
        )}
        {incidents.some((item) => item.sample) ? (
          <p className="mt-3 text-sm text-faint">{t(locale, "sampleNote")}</p>
        ) : null}
      </section>
    </div>
  );
}
