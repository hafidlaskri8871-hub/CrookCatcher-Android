import { useEffect, useState } from "react";
import { Cpu, Inbox, LockKeyhole, Radar, SlidersHorizontal } from "lucide-react";
import { Architecture } from "@/components/crook/architecture";
import { Command } from "@/components/crook/command";
import { Incidents } from "@/components/crook/incidents";
import { Settings } from "@/components/crook/settings";
import type { View } from "@/components/crook/shell-types";
import { Simulator } from "@/components/crook/simulator";
import { cn } from "@/lib/cn";
import type { CopyKey } from "@/lib/crook/i18n";
import { t } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";

const NAV: { id: View; key: CopyKey; icon: typeof Radar }[] = [
  { id: "ops", key: "navOps", icon: Radar },
  { id: "lock", key: "navLock", icon: LockKeyhole },
  { id: "cases", key: "navCases", icon: Inbox },
  { id: "arch", key: "navArch", icon: Cpu },
  { id: "prefs", key: "navPrefs", icon: SlidersHorizontal },
];

export function CrookApp() {
  const [view, setView] = useState<View>("ops");
  const settings = useCrook((s) => s.settings);
  const notice = useCrook((s) => s.notice);
  const dismiss = useCrook((s) => s.dismiss);
  const setFocus = useCrook((s) => s.setFocus);
  const locale = settings.locale;

  useEffect(() => {
    void useCrook.persist.rehydrate();
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale === "ar" ? "ar" : "en";
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
  }, [locale]);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(() => dismiss(), 2600);
    return () => window.clearTimeout(id);
  }, [notice, dismiss]);

  return (
    <div dir={locale === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-bg text-fg">
      <div className="mx-auto flex min-h-screen w-full max-w-6xl">
        <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-e border-line px-4 py-6 md:flex">
          <div className="flex items-center gap-3 px-2">
            <span className="grid size-10 place-items-center rounded-xl bg-signal text-on-signal">
              <LockKeyhole className="size-5" />
            </span>
            <span>
              <span className="block font-semibold tracking-tight">CrookCatcher</span>
              <span className="block text-xs text-muted">{t(locale, "markSub")}</span>
            </span>
          </div>
          <nav className="mt-8 flex flex-col gap-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setFocus(null);
                    setView(item.id);
                  }}
                  className={cn(
                    "flex min-h-11 items-center gap-3 rounded-xl px-3 text-start text-sm",
                    active ? "bg-raised text-fg" : "text-muted",
                  )}
                >
                  <Icon className={cn("size-4", active && "text-signal")} />
                  {t(locale, item.key)}
                </button>
              );
            })}
          </nav>
          <div className="mt-auto rounded-2xl border border-line bg-surface p-3">
            <div className="flex items-center gap-2">
              <span className={cn("size-2 rounded-full", settings.armed ? "bg-signal live-dot" : "bg-faint")} />
              <span className="text-sm font-medium">{settings.armed ? t(locale, "armed") : t(locale, "disarmed")}</span>
            </div>
            <p className="mt-2 font-mono text-xs text-faint">{t(locale, "footerArch")}</p>
          </div>
        </aside>
        <main className="min-w-0 flex-1 px-4 py-6 pb-28 md:px-8 md:pb-10">
          <div className="mb-5 flex items-center justify-between md:hidden">
            <div className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-lg bg-signal text-on-signal">
                <LockKeyhole className="size-4" />
              </span>
              <span className="font-semibold">CrookCatcher</span>
            </div>
            <span className="inline-flex min-h-9 items-center gap-2 rounded-full border border-line px-3 text-xs">
              <span className={cn("size-1.5 rounded-full", settings.armed ? "bg-signal live-dot" : "bg-faint")} />
              {settings.armed ? t(locale, "armed") : t(locale, "disarmed")}
            </span>
          </div>
          {view === "ops" && <Command go={setView} />}
          {view === "lock" && (
            <Simulator
              onOpenCase={() => {
                setView("cases");
              }}
            />
          )}
          {view === "cases" && <Incidents />}
          {view === "arch" && <Architecture />}
          {view === "prefs" && <Settings />}
        </main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-surface md:hidden">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = view === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setFocus(null);
                setView(item.id);
              }}
              className={cn(
                "flex min-h-16 flex-col items-center justify-center gap-1 text-xs",
                active ? "text-signal" : "text-muted",
              )}
            >
              <Icon className="size-5" />
              {t(locale, item.key)}
            </button>
          );
        })}
      </nav>
      {notice ? (
        <div
          role="status"
          className="fixed inset-x-4 bottom-20 z-30 mx-auto max-w-md rounded-2xl border border-line bg-raised px-4 py-3 text-sm text-fg shadow-none md:bottom-6"
        >
          {t(locale, notice)}
        </div>
      ) : null}
    </div>
  );
}
