import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Kicker({ children }: { children: ReactNode }) {
  return <p className="font-mono text-xs tracking-widest text-signal uppercase">{children}</p>;
}

export function PageTitle({ kicker, title, lede }: { kicker: string; title: string; lede: string }) {
  return (
    <header className="max-w-2xl">
      <Kicker>{kicker}</Kicker>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-fg md:text-4xl">{title}</h1>
      <p className="mt-3 text-base text-muted">{lede}</p>
    </header>
  );
}

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-2xl border border-line bg-surface p-4 md:p-5", className)}>{children}</section>;
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-fg">{label}</span>
      <div className="mt-2">{children}</div>
      {hint ? <span className="mt-2 block text-sm text-muted">{hint}</span> : null}
    </label>
  );
}

export const fieldClass =
  "w-full rounded-xl border border-line bg-bg px-3 py-3 text-base text-fg outline-none placeholder:text-faint";

export function SolidButton({
  children,
  onClick,
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className="inline-flex min-h-11 items-center justify-center rounded-xl bg-signal px-4 py-2 text-sm font-semibold text-on-signal disabled:opacity-50"
    >
      {children}
    </button>
  );
}

export function LineButton({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-bg px-4 py-2 text-sm font-medium text-fg disabled:opacity-50"
    >
      {children}
    </button>
  );
}

export function ToggleRow({
  on,
  label,
  body,
  onClick,
}: {
  on: boolean;
  label: string;
  body?: string;
  onClick: () => void;
}) {
  return (
    <button type="button" role="switch" aria-checked={on} onClick={onClick} className="flex w-full items-center gap-4 py-3 text-start">
      <span className="min-w-0 flex-1">
        <span className="block font-medium text-fg">{label}</span>
        {body ? <span className="mt-1 block text-sm text-muted">{body}</span> : null}
      </span>
      <span className={cn("flex h-7 w-12 shrink-0 rounded-full p-1", on ? "bg-signal" : "bg-line")}>
        <span
          className={cn(
            "block size-5 rounded-full bg-bg transition-transform",
            on && "translate-x-5 rtl:-translate-x-5",
          )}
        />
      </span>
    </button>
  );
}
