import { useRef, useState } from "react";
import { Delete } from "lucide-react";
import { PatternPad } from "@/components/crook/pattern";
import { Pipeline } from "@/components/crook/pipeline";
import { LineButton, PageTitle, Panel, SolidButton } from "@/components/crook/ui";
import { captureFrame, locate, openCamera, syntheticStill } from "@/lib/crook/capture";
import { formatWhen, samePattern } from "@/lib/crook/format";
import { t } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";
import type { Phase, UnlockMethod } from "@/lib/crook/types";
import { cn } from "@/lib/cn";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"] as const;

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function Simulator({ onOpenCase }: { onOpenCase: () => void }) {
  const settings = useCrook((s) => s.settings);
  const patchSettings = useCrook((s) => s.patchSettings);
  const pushEvent = useCrook((s) => s.pushEvent);
  const addIncident = useCrook((s) => s.addIncident);
  const noteFail = useCrook((s) => s.noteFail);
  const notify = useCrook((s) => s.notify);
  const locale = settings.locale;

  const [entry, setEntry] = useState("");
  const [path, setPath] = useState<number[]>([]);
  const [attempts, setAttempts] = useState(0);
  const [shake, setShake] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [phase, setPhase] = useState<Phase>(0);
  const [flash, setFlash] = useState(false);
  const busy = useRef(false);
  const entryRef = useRef("");

  function setDigits(next: string) {
    entryRef.current = next;
    setEntry(next);
  }

  async function beginCapture(method: UnlockMethod, count: number) {
    if (busy.current) return;
    busy.current = true;
    try {
      setPhase(1);
      setMessage(t(locale, "capturing"));
      pushEvent({ tone: "hot", k: "thresholdEvent" });
      const camPromise = openCamera();
      const geoPromise = locate();
      await wait(420);
      setPhase(2);
      if (settings.flash) {
        setFlash(true);
        window.setTimeout(() => setFlash(false), 180);
      }
      pushEvent({ tone: "hot", k: "camEvent" });
      const stream = await camPromise;
      const stamp = formatWhen(Date.now(), locale);
      let photo: string | null = null;
      let photoMode: "camera" | "synthetic" = "synthetic";
      if (stream) {
        try {
          photo = await captureFrame(stream, stamp);
          photoMode = "camera";
        } catch {
          photo = syntheticStill(stamp);
          notify("notifySynthetic");
        }
      } else {
        photo = syntheticStill(stamp);
        notify("notifySynthetic");
      }
      setPhase(3);
      const fix = await geoPromise;
      pushEvent({ tone: "warn", k: fix ? "gpsEvent" : "gpsNoneEvent" });
      await wait(360);
      setPhase(4);
      addIncident({
        id: `inc-${Date.now()}`,
        at: Date.now(),
        attempts: count,
        method,
        photo,
        photoMode,
        lat: fix?.lat ?? null,
        lng: fix?.lng ?? null,
        accuracy: fix?.accuracy ?? null,
        email: settings.email,
        deviceName: settings.deviceName,
        ownerName: settings.ownerName,
        driveCopy: settings.driveCopy,
        sample: false,
        seed: 0,
      });
      pushEvent({ tone: "hot", k: "mailEvent" });
      notify("notifySaved");
      await wait(280);
      setPhase(5);
      setDigits("");
      setPath([]);
      setAttempts(0);
      setMessage(null);
    } finally {
      busy.current = false;
    }
  }

  function fail(method: UnlockMethod, nextCount: number) {
    noteFail();
    pushEvent({ tone: "warn", k: "failEvent", n: nextCount });
    setAttempts(nextCount);
    setShake(true);
    window.setTimeout(() => setShake(false), 420);
    if (!settings.armed) {
      setMessage(t(locale, "disarmedNote"));
      setDigits("");
      setPath([]);
      return;
    }
    if (nextCount >= settings.threshold) {
      void beginCapture(method, nextCount);
      return;
    }
    const left = settings.threshold - nextCount;
    const key = left === 1 ? "remaining1" : left === 2 ? "remaining2" : "remainingN";
    setMessage(t(locale, key, { n: left }));
    setDigits("");
    setPath([]);
  }

  function submitPin(code: string) {
    if (busy.current || code.length < 4) return;
    if (code === settings.pin) {
      setMessage(t(locale, "unlocked"));
      pushEvent({ tone: "good", k: "okEvent" });
      notify("notifyUnlocked");
      setAttempts(0);
      setDigits("");
      return;
    }
    fail("pin", attempts + 1);
  }

  function pushDigit(digit: string) {
    if (busy.current || settings.method !== "pin") return;
    const next = (entryRef.current + digit).slice(0, 4);
    setDigits(next);
    if (next.length === 4) submitPin(next);
  }

  function submitPattern() {
    if (busy.current || path.length < 4) return;
    if (samePattern(path, settings.pattern)) {
      setMessage(t(locale, "unlocked"));
      pushEvent({ tone: "good", k: "okEvent" });
      notify("notifyUnlocked");
      setAttempts(0);
      setPath([]);
      return;
    }
    fail("pattern", attempts + 1);
  }

  return (
    <div className="flex flex-col gap-6">
      <PageTitle kicker={t(locale, "lockKicker")} title={t(locale, "lockTitle")} lede={t(locale, "lockLede")} />
      <p className="text-sm text-muted">{t(locale, "permAsk")}</p>
      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)]">
        <div className="mx-auto w-full max-w-80 rounded-4xl border border-line bg-bg p-3">
          <div className="relative overflow-hidden rounded-4xl border border-line bg-surface px-4 pt-5 pb-4">
            {flash ? <div className="absolute inset-0 bg-signal" /> : null}
            <div className="mx-auto mb-5 h-1.5 w-16 rounded-full bg-line" />
            <p className="text-center font-mono text-xs text-faint">{settings.deviceName}</p>
            <p className="mt-6 text-center text-sm text-muted">
              {settings.method === "pin" ? t(locale, "enterPin") : t(locale, "enterPattern")}
            </p>
            {settings.method === "pin" ? (
              <div className={cn("mt-4 flex justify-center gap-3", shake && "shake")}>
                {[0, 1, 2, 3].map((index) => (
                  <span
                    key={index}
                    className={cn(
                      "size-3 rounded-full border border-muted",
                      index < entry.length && "border-signal bg-signal",
                    )}
                  />
                ))}
              </div>
            ) : (
              <div className="mt-2">
                <PatternPad path={path} onPath={setPath} shake={shake} />
              </div>
            )}
            <p className="mt-4 min-h-12 text-center text-sm text-signal" aria-live="polite">
              {message}
            </p>
            {settings.method === "pin" ? (
              <div className="grid grid-cols-3 gap-2">
                {KEYS.map((key) => {
                  if (key === "") return <span key="gap" />;
                  if (key === "del") {
                    return (
                      <button
                        key="del"
                        type="button"
                        aria-label={t(locale, "wipe")}
                        onClick={() => setDigits(entryRef.current.slice(0, -1))}
                        className="grid h-14 place-items-center rounded-2xl text-fg"
                      >
                        <Delete className="size-5" />
                      </button>
                    );
                  }
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => pushDigit(key)}
                      className="grid h-14 place-items-center rounded-2xl bg-raised font-mono text-xl text-fg"
                    >
                      {key}
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="flex gap-2">
                <LineButton onClick={() => setPath([])}>{t(locale, "wipe")}</LineButton>
                <SolidButton onClick={submitPattern} disabled={path.length < 4 || busy.current}>
                  {t(locale, "confirm")}
                </SolidButton>
              </div>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <Panel>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => patchSettings({ method: "pin" })}
                className={cn(
                  "min-h-11 rounded-xl px-4 text-sm",
                  settings.method === "pin" ? "bg-signal text-on-signal" : "border border-line text-fg",
                )}
              >
                {t(locale, "pinMode")}
              </button>
              <button
                type="button"
                onClick={() => patchSettings({ method: "pattern" })}
                className={cn(
                  "min-h-11 rounded-xl px-4 text-sm",
                  settings.method === "pattern" ? "bg-signal text-on-signal" : "border border-line text-fg",
                )}
              >
                {t(locale, "patternMode")}
              </button>
            </div>
            <p className="mt-4 text-sm text-muted">{t(locale, "drillHint")}</p>
            <div className="mt-3">
              <SolidButton
                disabled={!settings.armed || busy.current}
                onClick={() => {
                  noteFail();
                  pushEvent({ tone: "warn", k: "failEvent", n: settings.threshold });
                  void beginCapture(settings.method, settings.threshold);
                }}
              >
                {t(locale, "quickFail")}
              </SolidButton>
            </div>
            {!settings.armed ? <p className="mt-3 text-sm text-signal">{t(locale, "disarmedNote")}</p> : null}
          </Panel>
          <Panel>
            <h2 className="font-medium text-fg">{t(locale, "pipelineTitle")}</h2>
            <Pipeline phase={phase === 0 && settings.armed ? 0 : phase} armed={settings.armed} locale={locale} />
            {phase === 5 ? (
              <div className="mt-3">
                <LineButton onClick={onOpenCase}>{t(locale, "openCase")}</LineButton>
              </div>
            ) : null}
          </Panel>
        </div>
      </div>
    </div>
  );
}
