import { useState } from "react";
import { EvidenceFrame } from "@/components/crook/evidence";
import { LineButton, PageTitle, Panel, SolidButton } from "@/components/crook/ui";
import { buildPacket, formatWhen, mapsUrl } from "@/lib/crook/format";
import { t } from "@/lib/crook/i18n";
import { useCrook } from "@/lib/crook/store";

export function Incidents() {
  const locale = useCrook((s) => s.settings.locale);
  const incidents = useCrook((s) => s.incidents);
  const focusId = useCrook((s) => s.focusId);
  const setFocus = useCrook((s) => s.setFocus);
  const removeIncident = useCrook((s) => s.removeIncident);
  const notify = useCrook((s) => s.notify);
  const [copied, setCopied] = useState(false);
  const open = incidents.find((item) => item.id === focusId) ?? null;

  async function copyPacket(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      notify("notifyCopied");
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  if (open) {
    const packet = buildPacket(open, locale);
    const shot =
      open.photoMode === "camera"
        ? t(locale, "cameraShot")
        : open.photoMode === "synthetic"
          ? t(locale, "syntheticShot")
          : t(locale, "sample");
    return (
      <div className="flex flex-col gap-5">
        <button type="button" onClick={() => setFocus(null)} className="min-h-11 self-start text-sm text-signal">
          {t(locale, "back")}
        </button>
        <header>
          <p className="font-mono text-xs tracking-widest text-signal uppercase">{shot}</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">{t(locale, "attempts", { n: open.attempts })}</h1>
        </header>
        <div className="grid gap-4 lg:grid-cols-[minmax(0,18rem)_minmax(0,1fr)]">
          <EvidenceFrame
            photo={open.photo}
            mode={open.photoMode}
            stamp={formatWhen(open.at, locale)}
            seed={open.seed}
            locale={locale}
          />
          <Panel className="flex flex-col gap-4">
            <dl className="grid gap-3 sm:grid-cols-2">
              <div>
                <dt className="text-sm text-muted">{t(locale, "when")}</dt>
                <dd className="mt-1 font-mono text-sm text-fg">{formatWhen(open.at, locale)}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">{t(locale, "toEmail")}</dt>
                <dd className="mt-1 text-sm break-all text-fg">{open.email}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">{t(locale, "device")}</dt>
                <dd className="mt-1 text-sm text-fg">{open.deviceName}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">{t(locale, "methodLabel")}</dt>
                <dd className="mt-1 text-sm text-fg">
                  {open.method === "pin" ? t(locale, "methodPin") : t(locale, "methodPattern")}
                </dd>
              </div>
              <div className="sm:col-span-2">
                <dt className="text-sm text-muted">{t(locale, "location")}</dt>
                <dd className="mt-1 font-mono text-sm text-fg">
                  {open.lat != null && open.lng != null
                    ? `${open.lat.toFixed(5)}, ${open.lng.toFixed(5)}`
                    : t(locale, "noLocation")}
                </dd>
                {open.accuracy != null ? (
                  <p className="mt-1 text-sm text-muted">{t(locale, "accuracy", { n: open.accuracy })}</p>
                ) : null}
              </div>
            </dl>
            {open.lat != null && open.lng != null ? (
              <a
                href={mapsUrl(open.lat, open.lng)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-11 items-center text-sm font-medium text-signal"
              >
                {t(locale, "openMap")}
              </a>
            ) : null}
            <p className="text-sm text-muted">{open.driveCopy ? t(locale, "driveOn") : t(locale, "driveOff")}</p>
            <div>
              <h2 className="text-sm font-medium text-fg">{t(locale, "packet")}</h2>
              <pre className="mt-2 overflow-auto rounded-xl border border-line bg-bg p-3 font-mono text-xs leading-relaxed whitespace-pre-wrap text-fg">
                {packet}
              </pre>
              <p className="mt-2 text-sm text-muted">{t(locale, "webDispatch")}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <SolidButton onClick={() => void copyPacket(packet)}>
                {copied ? t(locale, "copied") : t(locale, "copy")}
              </SolidButton>
              <LineButton
                onClick={() => {
                  removeIncident(open.id);
                }}
              >
                {t(locale, "delete")}
              </LineButton>
            </div>
          </Panel>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <PageTitle kicker={t(locale, "casesKicker")} title={t(locale, "casesTitle")} lede={t(locale, "webDispatch")} />
      {incidents.length === 0 ? (
        <Panel>
          <p className="text-muted">{t(locale, "emptyCases")}</p>
        </Panel>
      ) : (
        <ul className="flex flex-col gap-3">
          {incidents.map((incident) => (
            <li key={incident.id}>
              <button
                type="button"
                onClick={() => setFocus(incident.id)}
                className="grid w-full grid-cols-[6.5rem_minmax(0,1fr)] items-center gap-3 rounded-2xl border border-line bg-surface p-3 text-start"
              >
                <EvidenceFrame
                  photo={incident.photo}
                  mode={incident.photoMode}
                  stamp=""
                  seed={incident.seed}
                  locale={locale}
                  compact
                />
                <span className="min-w-0 py-1">
                  <span className="block font-medium text-fg">{t(locale, "attempts", { n: incident.attempts })}</span>
                  <span className="mt-1 block font-mono text-xs text-muted">{formatWhen(incident.at, locale)}</span>
                  <span className="mt-2 block font-mono text-xs break-all text-faint">
                    {incident.lat != null && incident.lng != null
                      ? `${incident.lat.toFixed(4)}, ${incident.lng.toFixed(4)}`
                      : t(locale, "noLocation")}
                  </span>
                  <span className="mt-2 block text-xs text-signal">
                    {incident.sample
                      ? t(locale, "sample")
                      : incident.photoMode === "camera"
                        ? t(locale, "cameraShot")
                        : t(locale, "syntheticShot")}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
