# App Builder Workspace

A TanStack Start (React 19 + Vite + TanStack Router) web app, with Android
packaging under `android/` and deployment targeted at Vercel.

## Stack

- **Framework:** [TanStack Start](https://tanstack.com/start) / TanStack Router
- **UI:** React 19, Tailwind CSS v4, Radix UI, shadcn-style components
- **Data:** Kysely + PostgreSQL (`pg`), PGlite for local/dev
- **Auth:** better-auth
- **Build/Deploy:** Vite, Vercel

## Getting started

```bash
npm install
cp .env.example .env   # fill in DATABASE_URL, BETTER_AUTH_SECRET, etc.
npm run dev
```

The dev server runs on `http://localhost:8080`.

## Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start the dev server |
| `npm run build` | Production build (also runs DB migrations) |
| `npm run db:migrate` | Run database migrations |
| `npm run typecheck` | TypeScript type checking |
| `npm run lint` | ESLint |
| `npm run format` | Prettier write |
| `npm test` | Run test suite |

## Project structure

```
src/
  components/   UI components
  lib/          App logic (auth, db, crook feature, multiplayer, etc.)
  routes/       TanStack Router routes
server/         Server-side middleware
migrations/     SQL migrations
android/        Android app wrapper (Gradle)
scripts/        Build/dev tooling scripts
```

## Environment variables

See `.env.example` for the full list of variables the app reads
(database, auth, and optional Grok-platform connector settings).

## License

Not specified.
